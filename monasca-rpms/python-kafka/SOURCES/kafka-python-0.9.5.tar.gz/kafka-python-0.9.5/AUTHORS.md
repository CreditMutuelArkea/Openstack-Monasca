# Current Maintainer
* Dana Powers, [@dpkp](https://github.com/dpkp)

# Original Author and First Commit
* David Arthur, [@mumrah](https://github.com/mumrah)

# Contributors - 2015 (alpha by username)
* Alex Couture-Beil, [@alexcb](https://github.com/alexcb)
* Ali-Akber Saifee, [@alisaifee](https://github.com/alisaifee)
* Christophe-Marie Duquesne, [@chmduquesne](https://github.com/chmduquesne)
* Thomas Dimson, [@cosbynator](https://github.com/cosbynator)
* Kasper Jacobsen, [@Dinoshauer](https://github.com/Dinoshauer)
* Ross Duggan, [@duggan](https://github.com/duggan)
* Enrico Canzonieri, [@ecanzonieri](https://github.com/ecanzonieri)
* haosdent, [@haosdent](https://github.com/haosdent)
* Arturo Filastò, [@hellais](https://github.com/hellais)
* Job Evers‐Meltzer, [@jobevers](https://github.com/jobevers)
* Martin Olveyra, [@kalessin](https://github.com/kalessin)
* Kubilay Kocak, [@koobs](https://github.com/koobs)
* Matthew L Daniel <mdaniel@gmail.com>
* Eric Hewitt, [@meandthewallaby](https://github.com/meandthewallaby)
* Oliver Jowett [@mutability](https://github.com/mutability)
* Shaolei Zhou, [@reAsOn2010](https://github.com/reAsOn2010)
* Oskari Saarenmaa, [@saaros](https://github.com/saaros)
* John Anderson, [@sontek](https://github.com/sontek)
* Eduard Iskandarov, [@toidi](https://github.com/toidi)
* Todd Palino, [@toddpalino](https://github.com/toddpalino)
* trbs, [@trbs](https://github.com/trbs)
* Viktor Shlapakov, [@vshlapakov](https://github.com/vshlapakov)
* Will Daly, [@wedaly](https://github.com/wedaly)
* Warren Kiser, [@wkiser](https://github.com/wkiser)
* William Ting, [@wting](https://github.com/wting)
* Zack Dever, [@zackdever](https://github.com/zackdever)

# More Contributors
* Bruno Renié, [@brutasse](https://github.com/brutasse)
* Thomas Dimson, [@cosbynator](https://github.com/cosbynator)
* Jesse Myers, [@jessemyers](https://github.com/jessemyers)
* Mahendra M, [@mahendra](https://github.com/mahendra)
* Miguel Eduardo Gil Biraud, [@mgilbir](https://github.com/mgilbir)
* Marc Labbé, [@mrtheb](https://github.com/mrtheb)
* Patrick Lucas, [@patricklucas](https://github.com/patricklucas)
* Omar Ghishan, [@rdiomar](https://github.com/rdiomar) - RIP, Omar. 2014
* Ivan Pouzyrevsky, [@sandello](https://github.com/sandello)
* Lou Marvin Caraig, [@se7entyse7en](https://github.com/se7entyse7en)
* waliaashish85, [@waliaashish85](https://github.com/waliaashish85)
* Mark Roberts, [@wizzat](https://github.com/wizzat)

Thanks to all who have contributed!
