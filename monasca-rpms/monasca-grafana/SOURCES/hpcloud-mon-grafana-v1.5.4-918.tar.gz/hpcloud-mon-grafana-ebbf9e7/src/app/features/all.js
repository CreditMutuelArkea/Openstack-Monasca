define([
  './panellinkeditor/module',
], function () {});
