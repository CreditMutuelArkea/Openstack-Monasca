define([
  './dashboard-from-db',
  './dashboard-from-file',
  './dashboard-from-script',
  './dashboard-default',
],
function () {});
